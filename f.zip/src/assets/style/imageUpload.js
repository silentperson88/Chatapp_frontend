import "assets/style/imageUpload.css";

const imageUpload = {
  dropzone: "custom-dropzone",
  inputLabel: "custom-input-label",
  preview: "custom-preview",
  inputLabelWithFiles: "custom-input-label-button",
};

export default imageUpload;
