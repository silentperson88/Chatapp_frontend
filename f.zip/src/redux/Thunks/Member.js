import { createAsyncThunk } from "@reduxjs/toolkit";
import ApiService from "redux/ApiService/ApiService";
import Sessions from "utils/Sessions";
// import Sessions from "utils/Sessions";

const getAllGroupsOfMember = createAsyncThunk("member", async () => {
  const res = await ApiService.get(`member`, {
    headers: { Authorization: `Bearer ${Sessions.userToken}` },
  })
    .then((r) => r)
    .catch((err) => err.response);
  return res;
});

export const createGroups = createAsyncThunk("group-create", async (data) => {
  const res = await ApiService.post(`group`, data, {
    headers: { Authorization: `Bearer ${Sessions.userToken}` },
  })
    .then((r) => r)
    .catch((err) => err.response);
  return res;
});

export default getAllGroupsOfMember;
