import { combineReducers, configureStore } from "@reduxjs/toolkit";
import ConfigReducer from "redux/Slice/Config";
import NotificationReducer from "redux/Slice/Notification";
import Groups from "redux/Slice/Groups";

export const rootReducer = combineReducers({
  config: ConfigReducer,
  Notification: NotificationReducer,
  group: Groups,
});

const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
});

export default store;
